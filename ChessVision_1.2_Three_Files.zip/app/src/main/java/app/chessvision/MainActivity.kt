package app.chessvision

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(17, 21, 25))
            setPadding((24 * density).toInt(), (28 * density).toInt(), (24 * density).toInt(), (28 * density).toInt())
        }
        root.addView(TextView(this).apply {
            text = "CHESS VISION"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "Распознавание доски · фигуры · отслеживание ходов"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, (12 * density).toInt(), 0, (28 * density).toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "Как начать:\n1. Откройте шахматную партию в начальной позиции.\n2. Нажмите «Начать захват экрана».\n3. Разрешите захват и вернитесь в шахматное приложение.\n4. Дождитесь сообщения «32 фигуры распознаны».\n\nДиагностика и подсказки будут отображаться поверх шахматной доски."
            textSize = 15f
            setTextColor(Color.WHITE)
            setLineSpacing(5f, 1f)
            setPadding((4 * density).toInt(), 0, (4 * density).toInt(), (28 * density).toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        startButton = Button(this).apply {
            textSize = 16f
            setOnClickListener { onStartStop() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        refreshButton()
    }

    override fun onResume() {
        super.onResume()
        if (::startButton.isInitialized) refreshButton()
    }

    private fun refreshButton() {
        startButton.text = if (CaptureService.running) "Остановить захват" else "Начать захват экрана"
    }

    private fun onStartStop() {
        if (CaptureService.running) {
            stopService(Intent(this, CaptureService::class.java))
            refreshButton()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Kept compatible with the project's no-AndroidX setup")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data))
            moveTaskToBack(true)
        }
    }

    companion object { private const val REQUEST_CAPTURE = 7 }
}
