package app.chessvision

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

data class RecognitionResult(val board: CharArray, val uncertainSquares: List<Int>, val occupiedSquares: Int)

/** Detects a flat 8x8 board and learns piece-shape templates from the standard initial position. */
class BoardVision {
    private var tpl: Map<Char, FloatArray>? = null
    private var colourThreshold = 0f
    var flipped = false; private set
    val ready get() = tpl != null
    var learningDiagnostic: String = "Ожидаю начальную позицию"
        private set

    private class Sq(val edge: FloatArray, val energy: Float, val center: Float)
    private companion object {
        const val N = 32
        // Edge energy is normalized to 0..1. Keep this low enough for small phone screens.
        const val OCCUPIED_THRESHOLD = 0.022f
        val FX = floatArrayOf(.5f, .3f, .7f, .3f, .7f)
        val FY = floatArrayOf(.5f, .3f, .3f, .7f, .7f)
    }

    private fun lum(p: Int) = 0.299f * (p shr 16 and 255) + 0.587f * (p shr 8 and 255) + 0.114f * (p and 255)
    private fun dist(a: Int, b: Int) = abs((a shr 16 and 255) - (b shr 16 and 255)) + abs((a shr 8 and 255) - (b shr 8 and 255)) + abs((a and 255) - (b and 255))

    private fun checker(b: Bitmap, x0: Int, y0: Int, s: Int): Float {
        if (s < 80 || x0 < 0 || y0 < 0 || x0 + s > b.width || y0 + s > b.height) return 0f
        val q = s / 8f
        val px = Array(2) { ArrayList<Int>() }
        for (r in 0..7) for (c in 0..7) {
            val x = (x0 + (c + .12f) * q).toInt().coerceIn(0, b.width - 1)
            val y = (y0 + (r + .12f) * q).toInt().coerceIn(0, b.height - 1)
            px[(r + c) and 1].add(b.getPixel(x, y))
        }
        val med = px.map { l -> l.sortedBy { lum(it) }[l.size / 2] }
        if (abs(lum(med[0]) - lum(med[1])) < 22f) return 0f
        var ok = 0
        for (g in 0..1) for (p in px[g]) if (dist(p, med[g]) < 58) ok++
        return ok / 64f
    }

    fun find(b: Bitmap): Rect? {
        val w = b.width
        var best: Rect? = null
        var bestScore = 0.76f
        val sizes = intArrayOf(w, w - w / 50, w - w / 25, w - w / 12).distinct().filter { it > 80 }
        for (s in sizes) {
            val x0 = (w - s) / 2
            var y = 0
            while (y + s <= b.height) {
                val score = checker(b, x0, y, s)
                if (score > bestScore) { bestScore = score; best = Rect(x0, y, x0 + s, y + s) }
                y += 3
            }
        }
        return best
    }

    fun still(b: Bitmap, r: Rect) = r.right <= b.width && r.bottom <= b.height && checker(b, r.left, r.top, r.width()) > 0.68f

    fun signature(b: Bitmap, r: Rect): ByteArray {
        val q = r.width() / 8f
        return ByteArray(64) { i ->
            var t = 0f
            for (k in 0..4) t += lum(b.getPixel((r.left + (i % 8 + FX[k]) * q).toInt().coerceIn(0,b.width-1), (r.top + (i / 8 + FY[k]) * q).toInt().coerceIn(0,b.height-1)))
            (t / 5 / 16).toInt().toByte()
        }
    }

    private fun features(b: Bitmap, r: Rect): List<Sq> {
        val s = r.width()
        val px = IntArray(s * s)
        Bitmap.createBitmap(b, r.left, r.top, s, s).getPixels(px, 0, s, 0, 0, s, s)
        val q = s / 8f
        val step = q * .76f / N
        val m = N - 2
        return (0..63).map { i ->
            val x0 = (i % 8) * q + q * .12f
            val y0 = (i / 8) * q + q * .12f
            val g = Array(N) { y -> FloatArray(N) { x ->
                var t = 0f
                for (dy in 0..1) for (dx in 0..1) {
                    val yy = min(s - 1, (y0 + (y + .25f + dy * .5f) * step).toInt())
                    val xx = min(s - 1, (x0 + (x + .25f + dx * .5f) * step).toInt())
                    t += lum(px[yy * s + xx])
                }
                t / 4f
            } }
            val e = FloatArray(m * m)
            var en = 0f; var count = 0
            for (y in 1 until N - 1) for (x in 1 until N - 1) {
                val gx = g[y][x + 1] - g[y][x - 1]
                val gy = g[y + 1][x] - g[y - 1][x]
                val mag = sqrt(gx * gx + gy * gy)
                e[(y - 1) * m + x - 1] = mag
                if (y in 8..24 && x in 8..24) { en += mag; count++ }
            }
            var centerSum = 0f
            for (y in 11..20) for (x in 11..20) centerSum += g[y][x]
            val background = (g[2][2] + g[2][N-3] + g[N-3][2] + g[N-3][N-3]) / 4f
            val centerMean = centerSum / 100f
            Sq(unit(e), en / count.coerceAtLeast(1) / 255f, (centerMean - background) / 100f)
        }
    }

    private fun unit(v: FloatArray): FloatArray {
        val mean = v.average().toFloat()
        var norm = 0f
        for (i in v.indices) { v[i] -= mean; norm += v[i] * v[i] }
        norm = sqrt(norm) + 1e-6f
        for (i in v.indices) v[i] /= norm
        return v
    }
    private fun dot(a: FloatArray, b: FloatArray): Float { var sum = 0f; for (i in a.indices) sum += a[i] * b[i]; return sum }
    private fun fr(i: Int) = if (!flipped) Pair(i % 8, 7 - i / 8) else Pair(7 - i % 8, i / 8)
    private fun startPiece(file: Int, rank: Int) = when (rank) { 0 -> "RNBQKBNR"[file]; 1 -> 'P'; 6 -> 'p'; else -> "rnbqkbnr"[file] }

    /** Learns only when the 32 occupied cells match the expected starting ranks. */
    fun learn(b: Bitmap, r: Rect): Boolean {
        tpl = null
        val f = try { features(b, r) } catch (e: Exception) {
            learningDiagnostic = "Не удалось прочитать клетки: ${e.message ?: "ошибка изображения"}"
            return false
        }
        val occupied = f.map { it.energy > OCCUPIED_THRESHOLD }
        val count = occupied.count { it }
        val top = (0..15).count { occupied[it] }
        val middle = (16..47).count { occupied[it] }
        val bottom = (48..63).count { occupied[it] }
        if (count != 32 || top != 16 || middle != 0 || bottom != 16) {
            learningDiagnostic = "Фигур обнаружено: $count/32\nВерхний ряд: $top/16 · середина: $middle/32 · нижний ряд: $bottom/16\nПорог детализации: ${"%.3f".format(OCCUPIED_THRESHOLD)}"
            return false
        }
        val upperMean = (0..15).map { f[it].center }.average().toFloat()
        val lowerMean = (48..63).map { f[it].center }.average().toFloat()
        // center values are normalized differences (roughly -2.5..+2.5), not 0..255 pixels.
        if (abs(upperMean - lowerMean) < 0.08f) {
            learningDiagnostic = "32 занятые клетки найдены, но цвета сторон не различаются.\nИзмените масштаб доски или тему фигур."
            return false
        }
        flipped = lowerMean < upperMean
        val templates = HashMap<Char, FloatArray>()
        var whiteCenter = 0f; var blackCenter = 0f
        var whiteCount = 0; var blackCount = 0
        for (i in (0..15) + (48..63)) {
            val (file, rank) = fr(i)
            val piece = startPiece(file, rank)
            val key = piece.lowercaseChar()
            val sum = templates.getOrPut(key) { FloatArray(f[i].edge.size) }
            for (k in sum.indices) sum[k] += f[i].edge[k]
            if (piece.isUpperCase()) { whiteCenter += f[i].center; whiteCount++ }
            else { blackCenter += f[i].center; blackCount++ }
        }
        templates.replaceAll { _, v -> unit(v) }
        whiteCenter /= whiteCount.coerceAtLeast(1)
        blackCenter /= blackCount.coerceAtLeast(1)
        colourThreshold = (whiteCenter + blackCenter) / 2f
        tpl = templates
        learningDiagnostic = "32 фигуры обнаружены. Шаблоны созданы."
        return true
    }

    fun readDetailed(b: Bitmap, r: Rect): RecognitionResult {
        val templates = tpl ?: return RecognitionResult(CharArray(64) { ' ' }, (0..63).toList(), 0)
        val f = features(b, r)
        val board = CharArray(64) { ' ' }
        val uncertain = ArrayList<Int>()
        var occupied = 0
        for (i in 0..63) if (f[i].energy > OCCUPIED_THRESHOLD) {
            occupied++
            val ranked = templates.entries.map { it.key to dot(it.value, f[i].edge) }.sortedByDescending { it.second }
            val best = ranked.first()
            val second = ranked.getOrNull(1)?.second ?: -1f
            if (best.second < 0.08f || best.second - second < 0.012f) uncertain += i
            val (file, rank) = fr(i)
            board[rank * 8 + file] = if (f[i].center > colourThreshold) best.first.uppercaseChar() else best.first
        }
        return RecognitionResult(board, uncertain, occupied)
    }

    fun read(b: Bitmap, r: Rect): CharArray = readDetailed(b, r).board

    fun fen(g: CharArray, turn: Char): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val c = g[rank * 8 + file]
                if (c == ' ') empty++ else { if (empty > 0) { sb.append(empty); empty = 0 }; sb.append(c) }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        var rights = ""
        if (g[4] == 'K') { if (g[7] == 'R') rights += "K"; if (g[0] == 'R') rights += "Q" }
        if (g[60] == 'k') { if (g[63] == 'r') rights += "k"; if (g[56] == 'r') rights += "q" }
        return "$sb $turn ${rights.ifEmpty { "-" }} - 0 1"
    }
}
